#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <errno.h>
#include <sys/wait.h>
#include <signal.h>

void usage()
{
	char buffer[128];
	sprintf(buffer,"Usage: p1 num_procs semilla limit\n");
	write(1,buffer,strlen(buffer));
	exit(0);
}

void f_sigalarm(int s)
{
	char buffer[128];
	sprintf(buffer, " Limite tiempo \n");	
	write(1,buffer, strlen(buffer));
	exit(0);
}
int main(int argc, char *argv[])
{
	uint p;
	int procs;
	int ret;
	int suma,aux;
	int res_p = 0;
	char semilla[64];
	char buffer[128];
	struct sigaction sa;
	int limit;
	sigset_t mymask;
	sigset_t oldmask;


	if (argc != 4) usage();
	procs = atoi(argv[1]);
	res_p = atoi(argv[2]);
	limit = atoi(argv[3]);
	sigfillset(&mymask);
	
	/* Bloqueamos todas */
	sigprocmask(SIG_BLOCK, &mymask, &oldmask);
	/* Capturamos signal */
	sa.sa_handler = f_sigalarm;
	sigfillset(&sa.sa_mask);
	sa.sa_flags = SA_RESTART;
	sigaction(SIGALRM, &sa, NULL);

	/* Ponemos la alarma */
	alarm(limit);

	/* Permitimos los signals + SIGLARM */
	sigdelset(&oldmask, SIGALRM);
	sigprocmask(SIG_SETMASK, &oldmask, NULL);
	

	for (p = 0; p < procs; p++){
		/* Creamos los procesos */	
		ret = fork();
		if (ret == 0){
			/* Preparamos el parametro */
			sprintf(semilla,"%d", res_p);
			/* Mutamos */
			execlp("./dummy","./dummy", semilla, NULL);
			perror("execlp");
			exit(0);
		}else if (ret < 0){
			perror("Fork");
			exit(0);
		}else{
			/* Esperamos que termine */
			ret = waitpid(-1,&aux,0);
			/* Cogemos el valor */
			res_p = res_p + WEXITSTATUS(aux);
		}
	}
	/* Imprimimos el resultado */
	sprintf(buffer,"EL total es %d\n", res_p);
	write(1,buffer,strlen(buffer));
}


