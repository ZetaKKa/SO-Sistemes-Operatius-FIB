#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>

int main(int argc, char *argv[])
{	
	int aux = atoi(argv[1]);
	aux ++;
	write(1, &aux, sizeof(aux));
	sleep(aux);
	exit(aux);
}


