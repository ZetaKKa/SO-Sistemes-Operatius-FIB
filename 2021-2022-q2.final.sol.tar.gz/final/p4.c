#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <errno.h>
#include <sys/wait.h>

void usage()
{
	char buffer[128];
	sprintf(buffer,"Usage: p1 num_procs semilla\n");
	write(1,buffer,strlen(buffer));
	exit(0);
}
int main(int argc, char *argv[])
{
	uint p;
	int procs;
	int ret;
	int suma,aux;
	int res_p = 0;
	char semilla[64];
	char buffer[128];
	int p_value[2];

	if (argc != 3) usage();
	procs = atoi(argv[1]);
	res_p = atoi(argv[2]);

	/* Create the pipe */
	pipe(p_value);

	ret = fork();
	if (ret == 0){
		int total = res_p;
		int val;
		close(p_value[1]);
		while(read(p_value[0],&val,sizeof(val)) > 0){
			total += val;
		}
		sprintf(buffer,"Total pipe es %d\n", total);
		write(1,buffer, strlen(buffer));
		exit(0);
		
	}else if (ret < 0 ){
		perror("Error fork");
		exit(0);
	}

	for (p = 0; p < procs; p++){
		ret = fork();
		if (ret == 0){
			dup2(p_value[1],1);
			close(p_value[0]);
			close(p_value[1]);
			sprintf(semilla,"%d", res_p);
			execlp("./dummy2","./dummy2", semilla, NULL);
			perror("execlp");
			exit(0);
		}else if (ret < 0){
			perror("Fork");
			exit(0);
		}else{
			ret = waitpid(-1,&aux,0);
			res_p = res_p + WEXITSTATUS(aux);
		}
	}
	sprintf(buffer,"EL total es %d\n", res_p);
	write(1,buffer,strlen(buffer));
}


