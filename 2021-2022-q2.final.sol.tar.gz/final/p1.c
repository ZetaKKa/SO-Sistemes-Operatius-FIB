#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <errno.h>
#include <sys/wait.h>

void usage()
{
	char buffer[128];
	sprintf(buffer,"Usage: p1 num_procs semilla\n");
	write(1,buffer,strlen(buffer));
	exit(0);
}
int main(int argc, char *argv[])
{
	uint p;
	int procs;
	int ret;
	int suma,aux;
	int res_p = 0;
	char semilla[64];
	char buffer[128];
	if (argc != 3) usage();
	procs = atoi(argv[1]);
	res_p = atoi(argv[2]);
	for (p = 0; p < procs; p++){
		ret = fork();
		if (ret == 0){
			sprintf(semilla,"%d", res_p);
			execlp("./dummy","./dummy", semilla, NULL);
			perror("execlp");
			exit(0);
		}else if (ret < 0){
			perror("Fork");
			exit(0);
		}else{
			ret = waitpid(-1,&aux,0);
			res_p = res_p + WEXITSTATUS(aux);
		}
	}
	sprintf(buffer,"EL total es %d\n", res_p);
	write(1,buffer,strlen(buffer));
}


