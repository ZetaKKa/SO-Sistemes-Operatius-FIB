#include <error.h>
#include <errno.h>
#include <signal.h>
#include <stdio.h>
#include <sys/wait.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>

int alive=0;

void check (int pid, int st, int *pids, int N, int *rdpipe)
{ 
      if (WIFEXITED (st))
        { 
          if (WEXITSTATUS (st) == 0)
            { 
              // Some child processes may be already dead
	      int j;
	      int idx=-1;
              for (j = 0; j < N; j++) { 
	        if (pids[j] == pid) 
		   idx = j; 
		else 
		   kill (pids[j], SIGKILL); 
	      } 
	      if (idx == -1)
	           error (1, 0, "unexpected error");

	      int n;
	      char c;
	      while ((n = read (rdpipe[idx], &c, 1)) > 0) { 
                   if (write (1, &c, 1) < 0)
                      error (1, errno, "write");
              }
	      if (n < 0)
	           error (1, errno, "read");

              fprintf (stderr, "%d ended correctly \n", pid);
              exit (0);
            }
          else
            { 
              fprintf (stderr, "%d wrong execution (exit code %d)\n", pid,
                       WEXITSTATUS (st));
            }
        }
      else if (WIFSIGNALED (st))
        { 
          fprintf (stderr, "%d wrong execution (signal %d: %s)\n", pid,
                   WTERMSIG (st), strsignal (WTERMSIG (st)));
        }
      else
        { 
          fprintf (stderr, "%d unexpected end\n", pid);
        }
}

int
main (int argc, char *argv[])
{
  int N;
  int *pids;
  int *rdpipe;

  if (argc != 3)
    error (1, 0, "Wrong parameters\nUsage: %s N filename", argv[0]);

  N = atoi (argv[1]);
  if (N < 0)
    error (1, 0, "N negative");
  if ((pids = malloc (N * sizeof (int))) == NULL)
    error (1, errno, "out of memory");
  if ((rdpipe = malloc (N * sizeof (int))) == NULL)
    error (1, errno, "out of memory");

  for (int i = 0; i < N; i++)
    {
      int fd[2];
      
      if (pipe (fd) < 0)
        error (1, errno, "pipe");

      switch (pids[i] = fork ())
        {
        case -1:
          error (1, errno, "Fork");

        case 0:
          if (dup2 (fd[1], 1) < 0) 
	     error (1, errno, "dup2"); 
	  if (close (fd[0]) < 0) 
	     error (1, errno, "close0"); 
	  if (close (fd[1]) < 0) 
	     error (1, errno, "close1");

          execl ("./hijo1", "hijo1", argv[2], NULL);
          error (1, errno, "exec");

	default:
          if (close (fd[1]) < 0) 
	     error (1, errno, "close1"); 
	  rdpipe[i] = fd[0];
	  alive++;

          int ret, st;
          while ((ret = waitpid (-1, &st, WNOHANG))>0) {
                if (ret == -1) 
		  error (1, errno, "waitpid");
		if (ret > 0) {
                  alive--;
	          check (ret, st, pids, N, rdpipe);
                }
           }
        }
    }

   while (alive > 0) {
      int pid, st;

      pid = wait (&st);
      if (pid == -1)
        error (1, errno, "wait");
      check (pid, st, pids, N, rdpipe);

      alive--;
    }

  fprintf (stderr, "Incalculable\n");
  exit (0);
}
