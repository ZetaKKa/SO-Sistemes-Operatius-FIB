#include <error.h>
#include <errno.h>
#include <signal.h>
#include <stdio.h>
#include <sys/wait.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>

int N, alive;
int *pids;
int seconds;

void
signal_handler (int signo)
{
  switch (signo)
      {
       case SIGINT:
              fprintf (stderr, "SIGINT\n");
	      for (int i = 0; i < N; i++)
	         kill (pids[i], SIGKILL);
	      exit (0);

       case SIGALRM:
              seconds++;
              fprintf (stderr, "%d seconds... \n", seconds);
	      alarm (1);
              break;

        default:
              error (1, 0, "Unexpected signal %d", signo);
											      }
}

void check (int pid, int st, int *pids)
{
      if (WIFEXITED (st))
        { 
          if (WEXITSTATUS (st) == 0)
            { 
              // Some child processes may be already dead
	      int j;
              for (j = 0; j < N; j++)
                kill (pids[j], SIGKILL);

              fprintf (stderr, "%d ended correctly  \n", pid);
              exit (0);
            }
          else
            { 
              fprintf (stderr, "%d wrong execution (exit code %d)\n", pid,
                       WEXITSTATUS (st));
            }
        }
      else if (WIFSIGNALED (st))
        { 
          fprintf (stderr, "%d wrong execution (signal %d: %s)\n", pid,
                   WTERMSIG (st), strsignal (WTERMSIG (st)));
        }
      else
        { 
          fprintf (stderr, "%d unexpected end\n", pid);
        }
}

int
main (int argc, char *argv[])
{
  int alive;
  struct sigaction handler;

  if (argc != 3)
    error (1, 0, "Wrong parameters\nUsage: %s N filename", argv[0]);

  N = atoi (argv[1]);
  if (N < 0)
    error (1, 0, "N negative");
  if ((pids = malloc (N * sizeof (int))) == NULL)
    error (1, errno, "out of memory");

  handler.sa_handler = signal_handler;
  handler.sa_flags = SA_RESTART;
  sigemptyset (&handler.sa_mask);
  if (sigaction (SIGINT, &handler, NULL) < 0)
    error (1, errno, "sigaction");
  if (sigaction (SIGALRM, &handler, NULL) < 0)
    error (1, errno, "sigaction");

  alarm(1);

  for (int i = 0; i < N; i++)
    {
      switch (pids[i] = fork ())
        {
        case -1:
          error (1, errno, "Fork");

        case 0:
          execl ("./hijo1", "hijo1", argv[2], NULL);
          error (1, errno, "exec");
	default:
	  alive++;

          int ret, st;
          while ((ret = waitpid (-1, &st, WNOHANG)>0)) {
                if (ret == -1) 
		  error (1, errno, "waitpid");
		if (ret > 0) {
                  alive--;
	          check (ret, st, pids);
                }
           }
        }
    }

   while (alive > 0) {
      int pid, st;

      pid = wait (&st);
      if (pid == -1)
        error (1, errno, "wait");
      check (pid, st, pids);

      alive--;
    }

  fprintf (stderr, "Incalculable\n");
  exit (0);
}
