#include <error.h>
#include <errno.h>
#include <signal.h>
#include <stdio.h>
#include <sys/wait.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>

// Strategy: standard input of main process is dumped into a temporary file.
// Each child opens and redirects this file to his standard input.
// 
// Child processes can not share the standard input file descriptor because
// read operations performed by a child process will affect the file pointer
// shared by all child processes. Then, each character will be read just
// by one child process.
//
// Temporary file is removed at execution end

#define TMPFILE "/tmp/clab2.txt"

int
main (int argc, char *argv[])
{
  int N, alive;
  int *pids;
  char c;
  int n, fd;

  if (argc != 2)
    error (1, 0, "Wrong parameters\nUsage: %s N", argv[0]);

  N = atoi (argv[1]);
  if (N < 0)
    error (1, 0, "N negative");
  if ((pids = malloc (N * sizeof (int))) == NULL)
    error (1, errno, "out of memory");

  fd = open (TMPFILE, O_WRONLY | O_TRUNC | O_CREAT, 0600);
  if (fd < 0)
    error (1, errno, "open tmp");
  while ((n = read (0, &c, 1)) > 0)
    if (write (fd, &c, 1) < 0)
      error (1, errno, "write tmp");
  if (n < 0)
    error (1, errno, "read tmp");
  if (close (fd) < 0)
    error (1, errno, "close tmp");

  for (int i = 0; i < N; i++)
    {
      switch (pids[i] = fork ())
        {
        case -1:
          error (1, errno, "Fork");

        case 0:
          if (close (0) < 0)
            error (1, errno, "close 0");
          if (open (TMPFILE, O_RDONLY) != 0)
            error (1, errno, "open");
          execl ("./hijo2", "hijo2", NULL);
          error (1, errno, "exec");
        }
    }

  alive = N;
  while (alive > 0)
    {
      int pid, st;

      pid = wait (&st);
      if (pid == -1)
        error (1, errno, "wait");

      if (WIFEXITED (st))
        {
          if (WEXITSTATUS (st) == 0)
            {
              // Some child processes may be already dead
              for (int j = 0; j < N; j++)
                kill (pids[j], SIGKILL);

              fprintf (stderr, "%d ended correctly\n", pid);
              unlink (TMPFILE);
              exit (0);
            }
          else
            {
              fprintf (stderr, "%d wrong execution (exit code %d)\n", pid,
                       WEXITSTATUS (st));
            }
        }
      else if (WIFSIGNALED (st))
        {
          fprintf (stderr, "%d wrong execution (signal %d: %s)\n", pid,
                   WTERMSIG (st), strsignal (WTERMSIG (st)));
        }
      else
        {
          fprintf (stderr, "%d unexpected end\n", pid);
        }
      alive--;
    }
  fprintf (stderr, "Incalculable\n");
  unlink (TMPFILE);
  exit (0);
}
