#include <error.h>
#include <errno.h>
#include <signal.h>
#include <stdio.h>
#include <sys/wait.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>

int
main (int argc, char *argv[])
{
  int N, alive;
  int *pids;

  if (argc != 3)
    error (1, 0, "Wrong parameters\nUsage: %s N filename", argv[0]);

  N = atoi (argv[1]);
  if (N < 0)
    error (1, 0, "N negative");
  if ((pids = malloc (N * sizeof (int))) == NULL)
    error (1, errno, "out of memory");

  for (int i = 0; i < N; i++)
    {
      switch (pids[i] = fork ())
        {
        case -1:
          error (1, errno, "Fork");

        case 0:
          execl ("./hijo1", "hijo1", argv[2], NULL);
          error (1, errno, "exec");
        }
    }

  alive = N;
  while (alive > 0)
    {
      int pid, st;

      pid = wait (&st);
      if (pid == -1)
        error (1, errno, "wait");

      if (WIFEXITED (st))
        {
          if (WEXITSTATUS (st) == 0)
            {
              // Some child processes may be already dead
              for (int j = 0; j < N; j++)
                kill (pids[j], SIGKILL);

              fprintf (stderr, "%d ended correctly\n", pid);
              exit (0);
            }
          else
            {
              fprintf (stderr, "%d wrong execution (exit code %d)\n", pid,
                       WEXITSTATUS (st));
            }
        }
      else if (WIFSIGNALED (st))
        {
          fprintf (stderr, "%d wrong execution (signal %d: %s)\n", pid,
                   WTERMSIG (st), strsignal (WTERMSIG (st)));
        }
      else
        {
          fprintf (stderr, "%d unexpected end\n", pid);
        }
      alive--;
    }
  fprintf (stderr, "Incalculable\n");
  exit (0);
}
